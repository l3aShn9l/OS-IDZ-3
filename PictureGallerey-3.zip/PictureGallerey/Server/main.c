// Server side implementation of UDP client-server model
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <pthread.h>

#define PORT    8888
#define MAXLINE 1024

#include "server.h"
#include "../Library/data.h"

// Функция которая запускется в потоке и обеспеичвает непрерывную работу сервера
// в бесконечном цикле сервер ждет запросов от клиентов
// Если от этого кллиента пришел первй запрос, то он добавляется в массив, инлекс в массиве - ид клиента
// Клиент присылает число, к какой картине хочет обратиться, ид клиента ставится в очередь к этой картине
void* manager_server(void* data)
{
    struct Server* server = (struct Server*) data;
    printf("Start server\n");
    #define MAXLINE 1024
    while (1)
    {
        char buffer[MAXLINE];
        struct sockaddr_in cliaddr;
        socklen_t len;
        int size_packet;

        len = sizeof(cliaddr);

        //size_packet = recvfrom(server->sockfd, (char *)buffer, MAXLINE, MSG_WAITALL, ( struct sockaddr *) &cliaddr, &len);
        size_packet = read(server->sockfd, (char*)buffer, MAXLINE);
        if (size_packet != sizeof (struct Packet))
        {
            perror("Parse Packet Failed");
            continue;
        }

        struct Packet packet = deserialize(buffer);
        if (packet.code_client == 10)
        {
            // если это клиент посетитель, его код = 10
            int client_id = get_id_client(server, cliaddr);
            if (client_id  == -1)
            {
                server->cliaddr[server->count_visitor] = cliaddr;
                client_id = server->count_visitor;
                server->count_visitor++;
            }

            printf("Client %d recv %d\n", client_id, packet.value);
            if (packet.value < COUNT_PICTURE)
            {
                // добавляем его запрос к очереди к картине
                printf("Add Client id %d in queue to Picture %d\n", client_id, packet.value);
                enqueue(&server->queues[packet.value], client_id);
            }

            continue;
        }

        if (packet.code_client == 1)
        {
            // проверяем, вдруг это первое подключение от галереи, тогда нужно сохранить ее адрес...
            if (server->gallerey_connect == 0)
            {
                server->gallerey_connect = 1;
                server->galladdr = cliaddr;
                printf("Client Gallerey is Connected...\n");
            }

            // Это запросы от клиента галлерею, код 1.
            // возможные операции:
            // 0-5 - посетитель с ид value закончил смотреть картину с номером code
            // 15 - запрос на получение клиента из очереди сервера на очередь в галерею,
            //     value - номер картины

            if (packet.code_operation < COUNT_PICTURE)
            {
                // если посетитель закончил смотреть картину, то отправляем ему запрос
                struct Packet response;
                response.code_client = 0;
                response.code_operation = 10;
                response.value = packet.code_operation;
                //sendto(server->sockfd, (const char *)buffer, sizeof(struct Packet), MSG_CONFIRM, (const struct sockaddr *) &server->cliaddr[packet.value], sizeof(server->cliaddr[packet.value]));
                connect(server->sockfd, (const struct sockaddr*)&server->cliaddr[packet.value], sizeof(server->cliaddr[packet.value]));
                write(server->sockfd, (const char*)buffer, sizeof(struct Packet));
                continue;
            }

            if (packet.code_operation == 15)
            {
                // если галлерея прислала запрос на получение очередного посетителя
                // берем посетителя из очереди к картине, и отправляем его ид на галерею
                // если в очереди нет посетителей, то в ответе код операции = 0
                struct Packet response;
                response.code_client = 0;
                int client_id = dequeue(&server->queues[packet.value]);
                if (client_id == -1)
                {
                    response.code_operation = 0;
                    response.value = 0;
                }
                else
                {
                    response.code_operation = 16;
                    response.value = client_id;
                }
                //sendto(server->sockfd, (const char *)serialize(response), sizeof(struct Packet), MSG_CONFIRM, (const struct sockaddr *) &server->galladdr, sizeof(server->galladdr));
                connect(server->sockfd, (const struct sockaddr*)&server->galladdr, sizeof(server->galladdr));
                write(server->sockfd, (const char*)serialize(response), sizeof(struct Packet));
            }
        }
    }
}



// Driver code
int main(int argc, char* argv[])
{
    char* ip_address = argv[1];
    int port = atoi(argv[2]);

    printf("Start Manager Gallerey\n");
    struct Server* server = init_server(port, ip_address);

    pthread_t thread_server;
    pthread_create(&thread_server, NULL, manager_server, (void*)server);

    pthread_join(thread_server, NULL);

    return 0;
}
