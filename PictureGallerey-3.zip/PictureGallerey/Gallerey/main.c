#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <pthread.h>

#define PORT    8888
#define MAXLINE 1024

#include "gallerey.h"
#include "../Library/data.h"

// Функция, которая будет крутиться в потоке и управлять работой галереи.
// Ее задача - в бесконечном цикле опрашивать очереди к картинам,
// и если к какой-то картине есть свободный доступ, то допускает к ней посетителя из очереди.
void* manager_gallerey(void* data)
{
    struct Gallerey* gallerey = (struct Gallerey*) data;
    printf("Start Gallerey\n");

    int sockfd;
    struct sockaddr_in     servaddr;

    // Creating socket file descriptor
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));

    // Filling server information
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(gallerey->port);
    servaddr.sin_addr.s_addr = inet_addr(gallerey->ip_address);

    while (1)
    {
        // ожидаем такт работы
        usleep(100 * WORK_TAKT);
        char* buffer = (char *) malloc(100);
        int size_packet;
        int len = sizeof(servaddr);
        // перебираем все картины в галерее
        for(int i = 0; i < COUNT_PICTURE; i++)
        {
            // Делаем запрос к серверу на получени посетителей в очередь к картине
            struct Packet packet;
            packet.code_client = 1;
            packet.code_operation = 15;
            packet.value = (unsigned int)i;
            sendto(sockfd, (const char *)serialize(packet), sizeof(struct Packet),
                   MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr));

            // Ожидаем ответ от сервера
            //size_packet = recvfrom(sockfd, (char *)buffer, 100, MSG_WAITALL, ( struct sockaddr *) &servaddr, &len);
            size_packet = read(sockfd, (char*)buffer, 100);
            if (size_packet != sizeof (struct Packet))
            {
                perror("Parse Packet Failed");
                continue;
            }
            struct Packet response = deserialize(buffer);
            if ((response.code_client == 0) && (response.code_operation == 16))
            {
                printf("Add Client id %d in queue to Picture %d\n", response.value, i);
                add_visitor(gallerey, i, response.value);
            }
            // Если у картины никого нет, то берем из очереди ид посетителя и ставим его к картине
            if (gallerey->timeouts[i] == 0)
            {
                // СМотрим, был ли кто около картины
                if (gallerey->pictures[i] != -1)
                {
                    // какой то посетитель был у картины, возвращаем ему информацию, что его время вышло
                    printf("Client id %d end show Picture %d\n", gallerey->pictures[i], i);
                    struct Packet request2;
                    request2.code_client = 1;
                    request2.code_operation = (unsigned int)i;
                    request2.value = (unsigned int)gallerey->pictures[i];
                    //sendto(sockfd, (const char *)serialize(request2), sizeof(struct Packet), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr));
                    connect(sockfd, (const struct sockaddr*)&servaddr, sizeof(servaddr));
                    write(sockfd, (const char*)serialize(request2), sizeof(struct Packet));

                }

                // Определяем кто следующий войдет к картине...
                int id = dequeue(&gallerey->queues[i]);
                if (id != -1)
                {
                    gallerey->pictures[i] = id;
                    printf("Client id %d start show Picture %d\n", id, i);
                    gallerey->timeouts[i] = TIMEOUT_VISITOR;
                }
                else
                    gallerey->pictures[i] = -1;
            }
            else
            {
                gallerey->timeouts[i]--;
            }
        }
    }
}

int main(int argc, char* argv[])
{
    char* ip_address = argv[1];
    int port = atoi(argv[2]);
    printf("Start Manager Gallerey\n");
    struct Gallerey* gallerey = init_gallerey(port, ip_address);
    pthread_t thread_gallerey;
    pthread_create(&thread_gallerey, NULL, manager_gallerey, (void*) gallerey);

    pthread_join(thread_gallerey, NULL);
    return 0;
}
