#ifndef DATA_H
#define DATA_H

#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>


struct Packet
{
    unsigned int code_client;
    unsigned int code_operation;
    unsigned int value;
};

char* serialize(struct Packet packet)
{
    char* buffer = (char*) malloc(sizeof (struct Packet));
    unsigned int code_client = ntohl(packet.code_client);
    unsigned int code_operation = ntohl(packet.code_operation);
    unsigned int value = ntohl(packet.value);
    memcpy(buffer, &code_client, sizeof(unsigned int));
    memcpy(buffer + sizeof (unsigned int), &code_operation, sizeof(unsigned int));
    memcpy(buffer + 2 * sizeof (unsigned int), &value, sizeof(unsigned int));
    return buffer;
}

struct Packet deserialize(char* buffer)
{
    struct Packet packet;
    unsigned int* value = (unsigned int*)&buffer[0];
    packet.code_client = ntohl(*value);
    value = (unsigned int*)&buffer[sizeof (unsigned int)];
    packet.code_client = ntohl(*value);
    value = (unsigned int*)&buffer[2 * sizeof(unsigned int)];
    packet.code_client = ntohl(*value);

    return packet;
}

#endif // DATA_H
