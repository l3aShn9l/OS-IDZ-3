#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <pthread.h>

#include "../Library/data.h"

#define SERVER_PORT 8888
#define COUNT_PICTURE 5
#define COUNT_WORKERS 10

struct Data
{
    int port;
    char* ip_address;
};

struct Data* init_data(int port, char* ip_address)
{
    struct Data* data = malloc(sizeof(struct Data));
    data->ip_address = ip_address;
    data->port = port;
    return data;
}

// Функция создает массив из чисел от 0 до n, и располагает их в случайном порядке
unsigned int* random_array(unsigned int size)
{
    unsigned int* array = (unsigned int*)malloc(size * sizeof(unsigned int));
    memset(array, 0, size);
    unsigned int value = 1;
    while (value < size)
    {
        unsigned int index = rand() % size;
        while (array[index] != 0)
            index = rand() % size;
        array[index] = value;
        value++;
    }
    return array;
}


// Функция потока. внутри потока запускает клиент
// Логика клиента простая, он формирует случаным образом порядок посещения картин
// и потом в этом порядке отправляет на сервер номер картины, которую хочет получить
// после этого ждет от сервера, что он просмотрел картину
void* work_client(void* udata)
{
    int sockfd;
    struct sockaddr_in     servaddr;
    struct Data* data = (struct Data*) udata;
    // Creating socket file descriptor
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));

    // Filling server information
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(data->port);
    servaddr.sin_addr.s_addr = inet_addr(data->ip_address);

    unsigned int* steps = random_array(COUNT_PICTURE);

    for(int i = 0; i < COUNT_PICTURE; i++)
    {
        sleep(rand() % 5 + 2); // Пауза от 2 до 6 секунд
        printf("Client want show to Picture %i\n", steps[i]);
        struct Packet packet;
        packet.code_client = 10;
        packet.code_operation = 1;
        packet.value = steps[i];

        // отправлемя на сервер номер картины, которую хотим посмотреть
        //sendto(sockfd, (const char *)serialize(packet), sizeof(struct Packet), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr));
        connect(sockfd, (const struct sockaddr*)&servaddr, sizeof(servaddr));
        write(sockfd, (const char*)serialize(packet), sizeof(struct Packet));

        int size_packet;
        int len = sizeof(servaddr);
        // ждем ответа от сервера, что картина просмотрена
        char* buffer = (char *) malloc(100);
        //size_packet = recvfrom(sockfd, (char *)buffer, 100, MSG_WAITALL, ( struct sockaddr *) &servaddr, &len);
        size_packet = read(sockfd, (char*)buffer, 100);
        if (size_packet != sizeof (struct Packet))
        {
            perror("Parse Packet Failed");
            continue;
        }
        struct Packet response = deserialize(buffer);
        if (response.code_client == 0)
        {
            printf("Client End show Picture %d\n", steps[i]);
        }

        free(buffer);
    }

    printf("Client End Works\n");

    return NULL;
}

int main(int argc, char* argv[])
{
    srand ( (unsigned int) time (0) );
    printf("Hello World!\n");
    printf("Running workers\n");
    pthread_t thread_worker[COUNT_WORKERS];
    char* ip_address = argv[1];
    int port = atoi(argv[2]);
    struct Data* data = init_data(port, ip_address);;
    for(int i = 0; i < COUNT_WORKERS; i++)
    {
        pthread_create(&thread_worker[i], NULL, work_client, (void*) data);
    }

    for(int i = 0; i < COUNT_WORKERS; i++)
    {
        pthread_join(thread_worker[i], NULL);
    }

    printf("All Client Stop...\n");
    return 0;
}
