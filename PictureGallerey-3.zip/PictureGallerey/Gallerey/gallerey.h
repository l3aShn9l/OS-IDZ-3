#ifndef GALLEREY_H
#define GALLEREY_H

#include "../Library/queue.h"

#define COUNT_PICTURE 5
#define MAX_SIZE_QUEUE_VISITORS 10

#define WORK_TAKT 500
#define TIMEOUT_VISITOR 10 // количество тактов, которое каждый посетитель тратит на просмотр картины


struct Gallerey
{
    int port;
    char* ip_address;
    int pictures[COUNT_PICTURE];   // ид текущего посетителя у картины, каждый посетитель стоит заданное количество тактов
    int timeouts[COUNT_PICTURE];
    node_t* queues[COUNT_PICTURE]; // очереди к каждой картине, клиенты сначала добавляются к ней
                                   // в очереди хранится ид посетителя
};


struct Gallerey* init_gallerey(int port, char* ip_address)
{
    struct Gallerey* gallerey = malloc(sizeof (struct Gallerey));
    for(int i = 0; i < COUNT_PICTURE; i++)
    {
        gallerey->timeouts[i] = 0;
        gallerey->pictures[i] = -1;
        gallerey->queues[i] = NULL;
    }
    gallerey->ip_address = ip_address;
    gallerey->port = port;
    return gallerey;
}

// Функция добавляет посетителя в очередь к картине, если добавление произошло успешно то возвращается 0
// если в очереди к картине нет места, то возвращается -1
int add_visitor(struct Gallerey* gallerey, int id_picture, int id_visitor)
{
    if (size(gallerey->queues[id_picture]) < MAX_SIZE_QUEUE_VISITORS)
    {
        enqueue(&gallerey->queues[id_picture], id_visitor);
        return 0;
    }
    return -1;
}

// Возвращает общее количество посетителей в галлерее
int count_visitor(struct Gallerey* gallerey)
{
    int count = 0;
    for(int i = 0; i < COUNT_PICTURE; i++)
    {
        if (gallerey->pictures[i] != 0)
            count++;
        count += size(gallerey->queues[i]);
    }
    return count;
}


#endif // GALLEREY_H
